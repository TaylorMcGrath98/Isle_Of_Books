	// JavaScript function returns true if user clicks yes, otherwise, false
	function confirmDel() {
		return confirm('Are you sure?');
	}