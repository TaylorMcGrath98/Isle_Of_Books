# --- Sample dataset

# --- !Ups

DELETE FROM GENRE;


INSERT INTO GENRE VALUES(1,'Non-Fiction', 'Non-Fiction');
INSERT INTO GENRE VALUES(2,'Drama', 'Drama');
INSERT INTO GENRE VALUES(3,'Sci-Fi', 'Sci-Fi');
INSERT INTO GENRE VALUES(4,'Cooking', 'Cooking');
INSERT INTO GENRE VALUES(5,'Poetry', 'Poetry');

INSERT INTO BOOKS VALUES (1,'Jane Eyre', 97801, 'Penguin Classics', 'A novel of intense power and intrigue, Jane Eyre has dazzled generations of readers with its depiction of a womans quest for freedom', 30, 10.00, 624, 2);