# Play Framework books Catalogue


## Add and edit books
## 1 to many database (Category 1 -- m books)
