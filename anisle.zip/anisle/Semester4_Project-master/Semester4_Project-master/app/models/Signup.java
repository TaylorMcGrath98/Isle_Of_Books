package models;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

// https://www.playframework.com/documentation/2.6.x/JavaEbean#Configuring-models
// https://www.playframework.com/documentation/2.6.0/api/java/play/data/validation/package-summary.html

@Entity
public class User extends Model {

    // Properties
    @Id
    private Long id;

    @Constraints.Required
    private String email;

    @Constraints.Required
    private String firstname;


    @Constraints.Required
    private String lastname;


    @Constraints.Required
    private String password;


    @Constraints.Required
    private String address;


    @Constraints.Required
    private String city;


    @Constraints.Required
    private String country;


    @Constraints.Required
    private String postcode;


    @Constraints.Required
    private String phone;



    public Feedback(Long id, @Constraints.Required String email, @Constraints.Required String phone, @Constraints.Required String city,@Constraints.Required String postcode,  @Constraints.Required String country, @Constraints.Required String password, @Constraints.Required String firstname, @Constraints.Required String lastname) {
        this.id = id;
        this.email = email;
        this.firstname = firstname;
        this.lastname = lastname;
        this.password = password;
        this.country = country;
        this.city = city;
        this.country = country;
        this.postcode = postcode;
        this.phone = phone;
    }

    public static final Finder<Long, Feedback> find = new Finder<>(Feedback.class);

    public static final List<Feedback> findAll() { // gets all objects
        return Feedback.find.all();
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstName() {
        return name;
    }

    public void setFirstName(String firstname) {
        this.firstname = firstname;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
    public String getPostCode() {
        return postcode;
    }

    public void setPostCode(String postcode) {
        this.postcode = postcode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}