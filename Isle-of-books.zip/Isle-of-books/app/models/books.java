package models;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

// https://www.playframework.com/documentation/2.6.x/JavaEbean#Configuring-models
// https://www.playframework.com/documentation/2.6.0/api/java/play/data/validation/package-summary.html

@Entity
public class books extends Model {

    // Properties
    @Id
    private Long id;

    @Constraints.Required
    private String title;

    @Constraints.Required
    private Bigint ISBN13;

    @Constraints.Required
    private Date publishDate;
    
    @Constraints.Required
    private String publisher;

    @Constraints.Required
    private String description;

    @Constraints.Min(0)
    private int stock;

    @Constraints.Min(0)
    private double price;

    @Constraints.Min(0)
    private int pages;

    @Constraints.Required
    private Bigint genreId;

    // Constructors
    public books() {

    }

    public books(Long id, String title, Bigint iSBN13, Date publishDate, String publisher, String description, int stock, double price, int pages, genre genreId) {
        this.id = id;
        this.title = title;
        this.iSBN13 = iSBN13;
        this.publishDate = publishDate;
        this.publisher = publisher;
        this.description = description;
        this.stock = stock;
        this.price = price;
        this.pages = pages;
        this.genreId = genreID;
    }

    //Generic query helper for entity Product with id type Long
    public static Finder<Long,Product> find = new Finder<>(Product.class);

    // Accessor Methods
    public Long getId()	{
		return this.id;
	}

	  public void setId(Long id)	{
		this.id = id;
    }
    
    public String getTitle()	{
		return this.title;
	}

	  public void setTitle(String title) {
		this.title = title;
    }

    public Bigint getISBN13()	{
      return this.iSBN13;
  }
  
    public void setInterSBN13(Bigint iSBN13) {
      this.iSBN13 = iSBN13;
      }
    
    public Date getPublishDate()	{
      return this.publishDate;
  }
  
    public void setPublishDate(Date publishDate) {
    this.publishDate = publishDate;
    }
    
    public String getPublisher()	{
      return this.Publisher;
  }
  
    public void setPublisher(String publisher) {
    this.publisher = publisher;
    }

    public String getDescription()	{
      return this.description;
  }
    
    public void setDescription(String description) {
      this.description = description;
      }
    
    public String getDescription()	{
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
    }
    
    public int getStock() {
		return this.stock;
	}

	public void setStock(int stock)	{
		  this.stock = stock;
    }
    
    public double getPrice() {
		return this.price;
	}

	public void setPrice(double price) {
	    this.price = price;
  }

    public int getPages() {
    return this.Pages;
    }

  public void setPages(int pages) {
        this.pages = pages;
    }

    public genre getGenreId()	{
    return this.genreId;
    }

  public void setGenre(genre genre) {
      this.genreId = genreId;
    }
  }