# Play Framework Product Catalogue


## Add and edit products
## 1 to many database (Category 1 -- m Product)
