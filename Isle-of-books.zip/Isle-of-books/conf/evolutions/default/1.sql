# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table genre (
  id                            bigint auto_increment not null,
  name                          varchar(255),
  genre                         varchar(255),
  constraint pk_genre primary key (id)
);

create table books (
  id                            bigint auto_increment not null,
  title                         varchar(255),
  iSBN13                        bigint,
  publishDate                   Date,
  publisher                     varchar(255),
  description                   varchar(255),
  stock                         integer not null,
  price                         double not null,
  pages                         int,
  genreId                       int,
  constraint pk_books primary key (id)
);

alter table books add constraint fk_books_category_id foreign key (genre_id) references genre (id) on delete restrict on update restrict;
create index ix_books_genre_id on books (genre_id);


# --- !Downs

alter table books drop constraint if exists fk_books_genre_id;
drop index if exists ix_books_genre_id;

drop table if exists genre;

drop table if exists books;

