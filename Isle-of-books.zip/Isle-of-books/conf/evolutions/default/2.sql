# --- Sample dataset

# --- !Ups

insert into genre (id,name,genre) values ( 1,'Fiction' );
insert into genre (id,name,genre) values ( 2,'Sci-fi' );
insert into genre (id,name,genre) values ( 3,'Poetry' );
insert into genre (id,name,genre) values ( 4,'Novel' );
insert into genre (id,name,genre) values ( 5,'' );
insert into genre (id,name,genre) values ( 6,'' );
insert into genre (id,name,genre) values ( 7,'' );
insert into genre (id,name,genre) values ( 8,'' );

insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
insert into books (id,title,iSBN13,publishDate,publisher,description,stock,price,pages,genreId) values ( );
